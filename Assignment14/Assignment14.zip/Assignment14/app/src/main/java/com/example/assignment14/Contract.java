package com.example.assignment14;

public class Contract {
    public static final String DATABASSE_NAME="user_db";
}
