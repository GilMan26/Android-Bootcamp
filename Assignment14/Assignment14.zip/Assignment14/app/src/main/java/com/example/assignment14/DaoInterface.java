package com.example.assignment14;

import java.util.List;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

@Dao
public interface DaoInterface {

    @Insert
    void addUser(User user);

    @Query("SELECT * FROM User")
    List<User> getAll();

    @Query("DROP DATABASE "+Contract.DATABASSE_NAME)
    void dropDb();

}
