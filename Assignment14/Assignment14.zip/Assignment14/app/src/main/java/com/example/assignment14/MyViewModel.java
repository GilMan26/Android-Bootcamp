package com.example.assignment14;

import androidx.lifecycle.ViewModel;

import java.util.List;

public class MyViewModel extends ViewModel {
    List<User> userList;
}
