package com.example.assignment14;

import android.content.Context;

import androidx.room.Room;

public class DatabaseSingleton {
    private static UserDatabase instance;

    public static UserDatabase getInstance(Context context) {
        if(instance==null)
            instance= Room.databaseBuilder(context,UserDatabase.class, Contract.DATABASSE_NAME).allowMainThreadQueries().build();
        return instance;
    }
}









